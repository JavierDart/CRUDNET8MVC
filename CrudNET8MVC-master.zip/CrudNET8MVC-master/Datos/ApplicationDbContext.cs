﻿using CrudNET8MVC.Models;
using Microsoft.EntityFrameworkCore;

namespace CrudNET8MVC.Datos
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }

        //agregamos los modelos aqui( cada modelo corresponde a una tabla en bbdd)
        public DbSet<Contacto> ModeloContacto {  get; set; }
    }
}
